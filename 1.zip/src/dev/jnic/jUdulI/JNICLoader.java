package dev.jnic.jUdulI;

public class JNICLoader {
}
