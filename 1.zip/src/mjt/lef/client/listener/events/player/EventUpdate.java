package mjt.lef.client.listener.events.player;

public class EventUpdate {
}
