package mjt.lef.client.module;

public enum Category {
    COMBAT,
    MOVEMENT,
    VISUAL
}
