package mjt.lef.client.bind;

public enum BindDevice {
    KEYBOARD, MOUSE, UNKNOWN
}
