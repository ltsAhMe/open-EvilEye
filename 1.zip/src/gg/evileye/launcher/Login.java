package gg.evileye.launcher;

public class Login {
    public boolean verifyAccount(String username, String password) {
        return true;
    }
}
